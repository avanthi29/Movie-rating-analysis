from flask import Flask, render_template, request, jsonify
import csv
import datetime
import os

app = Flask(__name__)

# Path to the movie data and click log files
MOVIE_FILE = 'movies.csv'
LOG_FILE = 'movie_clicks.csv'


# Read movie data from CSV
def get_movies():
    with open(MOVIE_FILE, newline='', encoding='utf-8') as csvfile:
        return list(csv.DictReader(csvfile))


# Write click data to a log
def log_click(movie_id, movie_name):
    with open(LOG_FILE, 'a', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([movie_id, movie_name, datetime.datetime.now()])


# Update the click count for each movie
def update_click_counts():
    movie_counts = {}
    try:
        with open(LOG_FILE, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                movie_id = row[0]
                movie_counts[movie_id] = movie_counts.get(movie_id, 0) + 1
    except FileNotFoundError:
        pass  # No clicks yet, will be created when a user clicks a movie

    return movie_counts


# Route to display the main page with movie list
@app.route("/")
def index():
    # Get movie details
    movies = get_movies()
    # Get click counts for each movie
    movie_counts = update_click_counts()

    # Add the click count to each movie
    for movie in movies:
        movie['click_count'] = movie_counts.get(movie['movie_id'], 0)
    
    # Pass the movies with click counts to the HTML template
    return render_template("index.html", movies=movies)


# Endpoint to track movie clicks
@app.route("/click", methods=["POST"])
def track_click():
    data = request.json
    movie_id = data["movie_id"]
    
    # Get movie name by movie_id
    movies = get_movies()
    movie_name = next((movie['title'] for movie in movies if movie['movie_id'] == movie_id), None)
    
    # Log the click
    if movie_name:
        log_click(movie_id, movie_name)

    # Return success response
    return jsonify(success=True)


# Route to display the clicks data
@app.route("/clicks")
def view_clicks():
    clicks = []
    try:
        with open(LOG_FILE, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                movie_id = row[0]
                movie_name = row[1]
                timestamp = row[2]
                clicks.append({"movie_id": movie_id, "movie_name": movie_name, "timestamp": timestamp})
    except FileNotFoundError:
        pass  # No clicks yet
    
    # Get total clicks for each movie
    movie_counts = update_click_counts()
    movies = get_movies()

    # Combine click data with movie information
    movie_data_with_clicks = []
    for movie in movies:
        movie_id = movie['movie_id']
        total_clicks = movie_counts.get(movie_id, 0)
        movie_data_with_clicks.append({
            "movie_id": movie_id,
            "movie_name": movie['title'],
            "total_clicks": total_clicks
        })
    
    return render_template("clicks.html", movie_data=movie_data_with_clicks)


if __name__ == "__main__":
    app.run(debug=True)

